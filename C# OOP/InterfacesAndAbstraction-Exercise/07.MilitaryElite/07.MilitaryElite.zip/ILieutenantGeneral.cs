﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07.MilitaryElite
{
    public interface ILieutenantGeneral
    {
        public List<Private> Privates { get; set; }
    }
}
